function greet (firstName, lastName, age) {
    console.log ('Hello,', firstName, lastName,'Jums', age)
}

greet ('Simona', 'Sidabraitė,', '28')