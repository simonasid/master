let person = {
    firstName: 'Simona',
    lastName: 'Sidabraitė',
    age: 28,
    email: 'ssidabraite@gmail.com',
    hobbies: 'plants',
}

console.log (person);

var defaults = {
    person: ['firstName','lastName','age','email','hobbies',]
   };