const x = 5;

if(x === 10) {
    console.log('x is 10');
} else if(x > 10) {
    console.log('x is greater than 10');
}    else {
        console.log('x is less than 10');
}