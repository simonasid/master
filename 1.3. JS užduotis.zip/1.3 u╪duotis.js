const fruits = ['Banana', 'Orange', 'Apple'];

fruits.push('Mango');

fruits.unshift('Strawberry');

console. log(fruits);