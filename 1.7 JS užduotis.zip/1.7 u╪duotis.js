const x = 6;
const y = 11;

/* if(x > 5 || y > 10) {
    console.log('x is more than 5 or y is more than 10');
} */

if(x > 5 || y > 10) {
    console.log('x is more than 5 or y is more than 10');
}